# Nearest stars to Earth
stars = [
        "Sol",
        "Alpha Centauri",
        "Barnard",
        "Wolf 359"
        ]
print("The Nearest star to Earth is: " + stars[3]) # Wolf 359


# Highest peak on each tectonic plate
peaks = {
"African" : "Kilimanjaro",
"Antarctic" : "Vinson",
"Australian" : "Puncak Jaya",
"Eurasian" : "Everest",
"North_American" : "Denali",
"Pacific" : "Mauna Kea",
"South_American" : "Aconcagua",
}

print( "The Highest peak is: " + peaks["Pacific"]) # Mauna Kea