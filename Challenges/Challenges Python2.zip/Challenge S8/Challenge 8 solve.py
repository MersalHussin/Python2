from cat import cat
meshmeshy = cat("hanfy","meshmeshy","syami" ,"6 monthes" , True , True ,False)
meshmeshy.isMeowing()
meshmeshy.iswalking(3)
meshmeshy.isrunning(20)
print("----------------------------------------------------------------------------------------")
# -----------------------------
sherazy = cat("semsma","white","sherazy" ,"3 monthes" ,True , True , True)
sherazy.isMeowing()
sherazy.iswalking(10)
sherazy.isrunning(50)
print("----------------------------------------------------------------------------------------")
# # -----------------------------
habashya = cat("antr","black","habashya" ,"9 monthes" ,True , True ,False)
habashya.isMeowing()
habashya.iswalking(1)
habashya.isrunning(100)
("----------------------------------------------------------------------------------------")
# # -----------------------------
