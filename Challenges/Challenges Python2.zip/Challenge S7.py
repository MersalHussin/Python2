def plant_recommendation(care):
    if care == 'low':
        print('صبار')
    elif care == 'medium':
        print('لبلاب')
    elif care == 'high':
        print('زهرة الاوركيد')
plant_recommendation('low')
plant_recommendation('medium')
plant_recommendation('high')